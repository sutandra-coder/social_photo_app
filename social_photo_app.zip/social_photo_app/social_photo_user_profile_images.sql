-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: socialphoto.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: social_photo
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_profile_images`
--

DROP TABLE IF EXISTS `user_profile_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profile_images` (
  `user_profile_image_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `image_no` int NOT NULL,
  `last_update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_profile_image_id`),
  KEY `user_profile_images_fk0` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile_images`
--

LOCK TABLES `user_profile_images` WRITE;
/*!40000 ALTER TABLE `user_profile_images` DISABLE KEYS */;
INSERT INTO `user_profile_images` VALUES (1,1,'https://d1lwvo1ffrod0a.cloudfront.net/1/ajay.jpg',1,'2022-04-29 12:44:18'),(2,1,'https://d1lwvo1ffrod0a.cloudfront.net/1/ajay.jpg',2,'2022-04-29 12:44:19'),(3,1,'https://d1lwvo1ffrod0a.cloudfront.net/1/ajay.jpg',3,'2022-04-29 12:44:20'),(4,1,'https://d1lwvo1ffrod0a.cloudfront.net/1/ajay.jpg',4,'2022-04-29 12:44:21'),(88,52,'https://d1lwvo1ffrod0a.cloudfront.net/52/selfie_1654268918171.jpg',3,'2022-06-03 15:08:44'),(87,52,'https://d1lwvo1ffrod0a.cloudfront.net/52/selfie_1654268867656.jpg',1,'2022-06-03 15:08:24'),(86,51,'https://d1lwvo1ffrod0a.cloudfront.net/51/selfie_1654268298489.jpg',3,'2022-06-03 14:58:23'),(85,51,'https://d1lwvo1ffrod0a.cloudfront.net/51/selfie_1654268274824.jpg',1,'2022-06-03 14:58:05'),(84,50,'https://d1lwvo1ffrod0a.cloudfront.net/50/selfie_1654264822443.jpg',3,'2022-06-03 14:00:31'),(83,50,'https://d1lwvo1ffrod0a.cloudfront.net/50/selfie_1654264786519.jpg',1,'2022-06-03 13:59:54'),(82,49,'https://d1lwvo1ffrod0a.cloudfront.net/49/selfie_1654264431684.jpg',3,'2022-06-03 13:53:58'),(81,49,'https://d1lwvo1ffrod0a.cloudfront.net/49/selfie_1654264411280.jpg',1,'2022-06-03 13:53:39'),(80,48,'https://d1lwvo1ffrod0a.cloudfront.net/48/selfie_1654264061645.jpg',3,'2022-06-03 13:47:47'),(79,48,'https://d1lwvo1ffrod0a.cloudfront.net/48/selfie_1654264039792.jpg',1,'2022-06-03 13:47:35'),(78,47,'https://d1lwvo1ffrod0a.cloudfront.net/47/selfie_1654257549784.jpg',3,'2022-06-03 11:59:17'),(77,47,'https://d1lwvo1ffrod0a.cloudfront.net/47/selfie_1654257517498.jpg',1,'2022-06-03 11:58:54'),(76,46,'https://d1lwvo1ffrod0a.cloudfront.net/46/selfie_1654234342214.jpg',3,'2022-06-03 05:32:27'),(75,46,'https://d1lwvo1ffrod0a.cloudfront.net/46/selfie_1654234321191.jpg',1,'2022-06-03 05:32:14'),(74,45,'https://d1lwvo1ffrod0a.cloudfront.net/45/selfie_1654228750466.jpg',3,'2022-06-03 03:59:17'),(73,45,'https://d1lwvo1ffrod0a.cloudfront.net/45/selfie_1654228657967.jpg',1,'2022-06-03 03:57:56'),(72,44,'https://d1lwvo1ffrod0a.cloudfront.net/44/selfie_1653310273717.jpg',3,'2022-05-23 12:51:20'),(71,44,'https://d1lwvo1ffrod0a.cloudfront.net/44/selfie_1653310248621.jpg',1,'2022-05-23 12:51:03'),(70,31,'https://d1lwvo1ffrod0a.cloudfront.net/31/selfie_1651675307687.jpg',3,'2022-05-04 14:41:52'),(69,31,'https://d1lwvo1ffrod0a.cloudfront.net/31/selfie_1651675274596.jpg',1,'2022-05-04 14:41:38'),(68,30,'https://d1lwvo1ffrod0a.cloudfront.net/30/selfie_1651583186624.jpg',3,'2022-05-03 13:06:31'),(67,30,'https://d1lwvo1ffrod0a.cloudfront.net/30/selfie_1651583167628.jpg',1,'2022-05-03 13:06:18'),(66,29,'https://d1lwvo1ffrod0a.cloudfront.net/29/selfie_1651580505967.jpg',3,'2022-05-03 12:21:51'),(65,29,'https://d1lwvo1ffrod0a.cloudfront.net/29/selfie_1651580479814.jpg',1,'2022-05-03 12:21:31'),(64,28,'https://d1lwvo1ffrod0a.cloudfront.net/28/selfie_1651576015534.jpg',3,'2022-05-03 11:06:58'),(63,28,'https://d1lwvo1ffrod0a.cloudfront.net/28/selfie_1651575999802.jpg',1,'2022-05-03 11:06:47'),(62,26,'https://d1lwvo1ffrod0a.cloudfront.net/26/selfie_1651575412133.jpg',3,'2022-05-03 10:56:58'),(61,26,'https://d1lwvo1ffrod0a.cloudfront.net/26/selfie_1651575392908.jpg',1,'2022-05-03 10:56:44'),(60,25,'https://d1lwvo1ffrod0a.cloudfront.net/25/selfie_1651572607639.jpg',3,'2022-05-03 10:10:10'),(59,25,'https://d1lwvo1ffrod0a.cloudfront.net/25/selfie_1651572591504.jpg',1,'2022-05-03 10:10:00'),(58,24,'https://d1lwvo1ffrod0a.cloudfront.net/24/selfie_1651498809803.jpg',3,'2022-05-02 13:40:16'),(57,24,'https://d1lwvo1ffrod0a.cloudfront.net/24/selfie_1651498796444.jpg',1,'2022-05-02 13:40:05'),(56,23,'https://d1lwvo1ffrod0a.cloudfront.net/23/selfie_1651483405410.jpg',3,'2022-05-02 09:23:30'),(55,23,'https://d1lwvo1ffrod0a.cloudfront.net/23/selfie_1651483388522.jpg',1,'2022-05-02 09:23:20'),(54,22,'https://d1lwvo1ffrod0a.cloudfront.net/22/selfie_1651483296010.jpg',3,'2022-05-02 09:21:40'),(53,22,'https://d1lwvo1ffrod0a.cloudfront.net/22/selfie_1651483280926.jpg',1,'2022-05-02 09:21:26'),(52,20,'https://d1lwvo1ffrod0a.cloudfront.net/20/selfie_1651388042872.jpg',3,'2022-05-01 06:54:11'),(51,20,'https://d1lwvo1ffrod0a.cloudfront.net/20/selfie_1651387997025.jpg',1,'2022-05-01 06:53:51'),(50,19,'https://d1lwvo1ffrod0a.cloudfront.net/19/selfie_1651387639759.jpg',3,'2022-05-01 06:47:28'),(49,19,'https://d1lwvo1ffrod0a.cloudfront.net/19/selfie_1651387583063.jpg',1,'2022-05-01 06:47:13'),(89,53,'https://d1lwvo1ffrod0a.cloudfront.net/53/selfie_1654273253040.jpg',1,'2022-06-03 16:21:03'),(90,53,'https://d1lwvo1ffrod0a.cloudfront.net/53/selfie_1654273268413.jpg',3,'2022-06-03 16:21:14'),(91,54,'https://d1lwvo1ffrod0a.cloudfront.net/54/selfie_1654330954081.jpg',1,'2022-06-04 08:22:50'),(92,54,'https://d1lwvo1ffrod0a.cloudfront.net/54/selfie_1654330979323.jpg',3,'2022-06-04 08:23:03'),(93,55,'https://d1lwvo1ffrod0a.cloudfront.net/55/selfie_1654331922092.jpg',1,'2022-06-04 08:38:54'),(94,55,'https://d1lwvo1ffrod0a.cloudfront.net/55/selfie_1654331946028.jpg',3,'2022-06-04 08:39:10'),(95,56,'https://d1lwvo1ffrod0a.cloudfront.net/56/selfie_1654332026063.jpg',1,'2022-06-04 08:40:37'),(96,56,'https://d1lwvo1ffrod0a.cloudfront.net/56/selfie_1654332042034.jpg',3,'2022-06-04 08:40:46'),(97,57,'https://d1lwvo1ffrod0a.cloudfront.net/57/selfie_1654332086803.jpg',1,'2022-06-04 08:41:38'),(98,57,'https://d1lwvo1ffrod0a.cloudfront.net/57/selfie_1654332103459.jpg',3,'2022-06-04 08:41:48'),(99,58,'https://d1lwvo1ffrod0a.cloudfront.net/58/selfie_1654332159557.jpg',1,'2022-06-04 08:42:56'),(100,58,'https://d1lwvo1ffrod0a.cloudfront.net/58/selfie_1654332184400.jpg',3,'2022-06-04 08:43:11'),(101,59,'https://d1lwvo1ffrod0a.cloudfront.net/59/selfie_1654332912847.jpg',1,'2022-06-04 08:55:21'),(102,59,'https://d1lwvo1ffrod0a.cloudfront.net/59/selfie_1654332932611.jpg',3,'2022-06-04 08:55:38'),(103,60,'https://d1lwvo1ffrod0a.cloudfront.net/60/selfie_1654335394111.jpg',1,'2022-06-04 09:36:44'),(104,60,'https://d1lwvo1ffrod0a.cloudfront.net/60/selfie_1654335409365.jpg',3,'2022-06-04 09:36:54'),(105,61,'https://d1lwvo1ffrod0a.cloudfront.net/61/selfie_1654337496704.jpg',1,'2022-06-04 10:11:47'),(106,61,'https://d1lwvo1ffrod0a.cloudfront.net/61/selfie_1654337512450.jpg',3,'2022-06-04 10:11:58'),(107,0,'https://d1lwvo1ffrod0a.cloudfront.net/2/scaled_2986e76d-57dc-4e24-9782-b7e60df534de5842354843337223002.jpg',1,'2022-07-07 10:14:08');
/*!40000 ALTER TABLE `user_profile_images` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 15:44:47
